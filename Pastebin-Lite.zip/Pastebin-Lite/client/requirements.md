## Packages
date-fns | Formatting dates for display
framer-motion | Smooth transitions and animations for the UI

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["'DM Sans'", "sans-serif"],
  mono: ["'JetBrains Mono'", "monospace"],
}
